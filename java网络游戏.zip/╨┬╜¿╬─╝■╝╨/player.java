package game;

import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class player extends JPanel implements KeyListener {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private int racketX = 100;
    private int racketWidth = 50;
    private int ballX = 150;
    private int ballY = 50;
    private int ballSize = 10;

    public player() {
        try {
            socket = new Socket("localhost", 1234);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            addKeyListener(this);
            setFocusable(true);

            // 使用Timer定期重绘游戏界面
            Timer timer = new Timer(1, e -> repaint());
            timer.start();

            new Thread(() -> {
                try {
                    String serverResponse;
                    while ((serverResponse = in.readLine()) != null) {
                        if (serverResponse.equals("GAME_OVER")) {
                            JOptionPane.showMessageDialog(this, "Game Over!");
                            break;
                        } else if (serverResponse.startsWith("UPDATE")) {
                            String[] parts = serverResponse.split(" ");
                            racketX = Integer.parseInt(parts[1]);
                            ballX = Integer.parseInt(parts[2]);
                            ballY = Integer.parseInt(parts[3]);
                            repaint();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.fillRect(racketX, 350, racketWidth, 10); // 拍子
        g.setColor(Color.BLUE);
        g.fillOval(ballX, ballY, ballSize, ballSize); // 球
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            out.println("MOVE_RACKET -10");
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            out.println("MOVE_RACKET 10");
        }
        out.flush();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ball Game");
        player game = new player();
        frame.add(game);
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
