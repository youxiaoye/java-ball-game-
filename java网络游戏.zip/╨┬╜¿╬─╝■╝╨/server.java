package game;
import java.io.*;
import java.net.*;

public class server {
    public static void main(String[] args) {
        int port = 1234;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("connect to port:" + port);
            while (true) {
                Socket playersocket = serverSocket.accept();
                new Thread(new playerhandler(playersocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class playerhandler implements Runnable {
        private Socket playersocket;
        private int racketX = 100;
        private int racketWidth = 50;
        private int racketHeight = 10;
        private int ballX = 150;
        private int ballY = 50;
        private int ballSize = 10;
        private int ballSpeedY = 5;
        private int ballSpeedX = 3;
        private boolean gameRunning = true;

        public playerhandler(Socket socket) {
            this.playersocket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(playersocket.getInputStream()));
                 PrintWriter out = new PrintWriter(playersocket.getOutputStream(), true)) {

                // 启动一个线程来更新球的位置
                new Thread(() -> {
                    while (gameRunning) {
                        ballX += ballSpeedX;
                        ballY += ballSpeedY;

                        // 检查球是否触碰到左右边界
                        if (ballX <= 0 || ballX >= 400 - ballSize) { // 假设游戏窗口宽度为400
                            ballSpeedX = -ballSpeedX;
                        }

                        // 检查球是否触碰到上边界
                        if (ballY <= 0) {
                            ballSpeedY = -ballSpeedY;
                        }

                        // 检查球是否触碰到拍子
                        if (ballY + ballSize >= 350 && ballY + ballSize <= 350 + racketHeight) { // 假设拍子固定在Y坐标350处
                            if (ballX >= racketX && ballX <= (racketX + racketWidth)) {
                                ballSpeedY = -ballSpeedY; // 反弹
                            }
                        }

                        // 检查球是否触碰到下边界
                        if (ballY >= 400 - ballSize) { // 假设游戏窗口高度为400
                            if (!(ballX >= racketX && ballX <= (racketX + racketWidth))) {
                                gameRunning = false;
                                out.println("GAME_OVER");
                            }
                        }

                        // 发送更新后的游戏状态给客户端
                        out.println("UPDATE " + racketX + " " + ballX + " " + ballY);

                        try {
                            Thread.sleep(30); // 控制球的移动速度
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    if (inputLine.startsWith("MOVE_RACKET")) {
                        int move = Integer.parseInt(inputLine.split(" ")[1]);
                        racketX += move;
                        if (racketX < 0) racketX = 0;
                        if (racketX > 400 - racketWidth) racketX = 400 - racketWidth;
                    }
                }
            } catch (IOException e) {
                System.out.println("与客户端通信失败");
                e.printStackTrace();
            } finally {
                try {
                    playersocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
